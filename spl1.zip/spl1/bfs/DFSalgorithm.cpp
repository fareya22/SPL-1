#include <iostream>
#include <climits>

void dfs_visit(int graph[][14], int vertex, int newSource);

char color[14];
int discovery_time[14];
int finishing_time[14];
int parent[14];
int path[14];
int times;

void dfs(int graph[][14], int vertex, int source)
{
    for (int i = 1; i <= vertex; i++)
    {
        color[i] = 'W';
        discovery_time[i] = INT_MAX;
        finishing_time[i] = INT_MAX;
        parent[i] = -1;
    }

    dfs_visit(graph, vertex, source);
    for (int i = 1; i <= vertex; i++)
    {
        if (color[i] == 'W')
        {
            dfs_visit(graph, vertex, i);
        }
    }

    for (int i = 1; i <= vertex; i++)
    {
        std::cout << "Parent of " << i << " is: " << parent[i] << std::endl;
        std::cout << "Discovery time of " << i << " is: " << discovery_time[i] << std::endl;
        std::cout << "Finishing time of " << i << " is: " << finishing_time[i] << std::endl;
    }
}

void dfs_visit(int graph[][14], int vertex, int newSource)
{
    color[newSource] = 'G';
    times++;
    discovery_time[newSource] = times;

    for (int j = 1; j <= vertex; j++)
    {
        if (graph[newSource][j] == 1 && color[j] == 'W')
        {
            parent[j] = newSource;
            path[j] = path[newSource] + 1;
            dfs_visit(graph, vertex, j);
        }
    }
    color[newSource] = 'B';
    times++;
    finishing_time[newSource] = times;
}

int main()
{
    int graph[14][14] = {
        {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };

    dfs(graph, 13, 0);

    return 0;
}
