
      int i=0;
      int j =10;
      if(i>2)
      {
            printf("Greater then 2");
      }
      else
      {
            k = j;
      }
      i =2;
     printf("%d",i);
