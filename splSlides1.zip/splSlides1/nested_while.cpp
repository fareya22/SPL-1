#include<stdio.h>
int main()
{
     int i =0;
        while ( true )
        {
                while ( i >= 0)
                {
                         i = i - 1;
                }
        }
        cout << i << endl;
}
