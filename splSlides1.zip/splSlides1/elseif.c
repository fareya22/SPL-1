#include<stdio.h>
int main()
{
    int a=1,b=2;
    if(a+b>3)
        printf("Sum grater than 3\n");
    else
        printf("Sum less than 3\n");
      int i =0;
        for(  i  = 1 ;  i  <= 10;  i++)
        {
               for ( j = 0 ; j <= 10 ; j++)
               {
                       cout << "SPL" <<endl;
               }
        }
}
